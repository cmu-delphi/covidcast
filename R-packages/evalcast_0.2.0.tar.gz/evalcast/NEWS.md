# evalcast 0.2.0

- Major overhaul of functionality
- Forecasters and evaluation scripts now operate on and result in "long" data 
frames
- Increased plotting flexibility
- Various utility functions added for increased evaluation/visualization
flexibility
- Integration with [zoltr](https://docs.zoltardata.com/zoltr/) for some forecast
retrieval as well as [covidHubUtils](https://github.com/reichlab/covidHubUtils)


# evalcast 0.1.0

- First major release.
