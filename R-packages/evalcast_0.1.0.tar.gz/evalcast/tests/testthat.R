library(testthat)
library(evalcast)

test_check("evalcast")
